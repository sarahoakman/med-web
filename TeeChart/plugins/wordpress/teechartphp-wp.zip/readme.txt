=== TeeChart ===
Contributors: steema
Donate link: http://steema.us/wp
Tags: chart, graph, plot, charting, plotting, graphing, stats, finance, stocks, widget, graphics, steema.com, charts
Requires at least: 2.2
Tested up to: 3.0.1
Stable tag: 1.0.3

Create and display charts and graphics.

== Description ==

This plugin enables adding charts to your WordPress blogs.

== Features ==

* Multiple sources of data
* Many chart styles
* Completely configurable
* 

== Installation ==

1. Upload the `teechartphp_wp` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Add the following shortcode to your page content:
   [teechartphp title="Hello WordPress !" data="40,80,20" view3D="false" style="Bar" legend="true" labels="Jan,Feb,Mar"]

== Frequently Asked Questions ==

1.

== Changelog ==

= 1.0.0 =
* Initial version

== Upgrade Notice ==

= 1.0.0 =
* Initial version

== Screenshots ==

1. teechartphp-wordpress-screenshot.png

