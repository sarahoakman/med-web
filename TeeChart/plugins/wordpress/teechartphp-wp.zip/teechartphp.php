<?php

/*
Plugin Name: TeeChartPHP
Version: 1.0.23
Plugin URI: http://www.steema.com
Description: Create and display charts on your WordPress blogs.
Author: Steema Software, steema
Author URI: http://www.steema.com
*/

// includes
include_once dirname(__FILE__).'/sources/TChart.php';


function GetFileDir($php_self){
  $filename = explode("/", $php_self); // THIS WILL BREAK DOWN THE PATH INTO AN ARRAY
  $filename2='';
  for( $i = 0; $i < (count($filename) - 1); ++$i ) {
    $filename2 .= $filename[$i].'/';
  }

  return $filename2;
}

function teephp_shortcode($atts, $content=null, $code="")
{
  extract( shortcode_atts( array(
		'title' => 'TeeChart PHP for WordPress',
		'data' => '',
                'labels' => '',
                'style' => 'Bar',
                'width' => '400',
                'height' => '250',
                'view3D' => 'false',
                'legend' => 'true',
	), $atts ) );

  $chart = new TChart($width,$height);

  if ($title != "")
    $chart->getHeader()->setText($title);

  if ($view3D != "true")
    $chart->getAspect()->setView3D($view3D);

  if ($legend != "true")
    $chart->getLegend()->setVisible(false);

  $chart->addSeries(new $style($chart->getChart()));
  $series = $chart->getSeries(0);

  if ($data != "")
  {
    $yValues = explode(',', $data);
    $series->addArray($yValues);
  }

  if ($labels != "")
  {
    $sLabels = explode(',', $labels);
    $series->setLabels($sLabels);
  }

  $chart->render( dirname(__FILE__). "/images/chart.png");

  $r = '<img src="' . GetFileDir($_SERVER['PHP_SELF']) . '/wp-content/plugins/teechartphp-wp/images/chart.png" alt="TeeChart for PHP" id="Steema"/>';
  return $r;
}

add_shortcode('teechartphp','teephp_shortcode');

?>